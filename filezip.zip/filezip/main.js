cc.game.onStart = function () {
    var sys = cc.sys;
    if (!sys.isNative && document.getElementById("cocosLoading")) //If referenced loading.js, please remove it
        document.body.removeChild(document.getElementById("cocosLoading"));

    // Pass true to enable retina display, on Android disabled by default to improve performance
    cc.view.enableRetina(sys.os === sys.OS_IOS ? true : false);

    // Disable auto full screen on baidu and wechat, you might also want to eliminate sys.BROWSER_TYPE_MOBILE_QQ
    if (sys.isMobile &&
        sys.browserType !== sys.BROWSER_TYPE_BAIDU &&
        sys.browserType !== sys.BROWSER_TYPE_WECHAT) {
        cc.view.enableAutoFullScreen(true);
    }
    cc.game.on(cc.game.EVENT_HIDE, function() {
           console.log("Game is paused or hidden.");
           // Có thể xử lý gì đó khi game bị pause hoặc bị ẩn (bằng cách chuyển ứng dụng sang nền)
       });

       // Lắng nghe sự kiện khi game quay lại (resume)
       cc.game.on(cc.game.EVENT_SHOW, function() {
           console.log("Game is resumed or shown.");
           // Có thể xử lý gì đó khi game quay lại từ nền
       });

    // Adjust viewport meta
    cc.view.adjustViewPort(true);

    // Uncomment the following line to set a fixed orientation for your game
    // cc.view.setOrientation(cc.ORIENTATION_PORTRAIT);

    // Setup the resolution policy and design resolution size
    cc.view.setDesignResolutionSize(1280, 720, cc.ResolutionPolicy.EXACT_FIT);

    // The game will be resized when browser size change
    cc.view.resizeWithBrowserSize(true);

    //load resources
    cc.LoaderScene.preload(g_resources, function () {
        cc.director.runScene(new SplashScene());
    }, this);
};
cc.game.run();
